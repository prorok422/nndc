$(function() {


    // $.getJSON( "http://frontend-test.pingbull.com/pages/stepan.bondarenkoo@gmail.com/comments", function( data ) {
    // $.getJSON( "json/comments.json", function( data ) {
    //     var items = [];
    //     $.each( data, function( key, val ) {
    //         items.push( "<li id='" + key + "'>" + val.id + "</li>" );
    //     });
    //
    //     $( "<ul/>", {
    //         "class": "my-new-list",
    //         html: items.join( "" )
    //     }).appendTo( "body" );
    // });


});
